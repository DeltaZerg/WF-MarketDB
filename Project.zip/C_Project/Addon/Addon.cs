﻿using System;

namespace Addon
{
    public static class Addon
    {

    }
}
